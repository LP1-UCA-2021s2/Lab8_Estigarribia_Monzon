/*
 ============================================================================
 Name        : listas_enlazadas.c
 Author      : Martin Monzon, Jorge Estigarribia
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct Node //definicion de nodo para lista enlazada
{
    int data;
    struct Node* next;
}tnode;

typedef tnode *tpointer; //Puntero al tipo de dato tnodo para no utilizar punteros de punteros



void bSort(int *p, int length)
{
	int i=0;
	int j=0;
	for(i=1;i<length;i++)
	{
		for(j=0;j<length-i;j++)
		{
			if(p[i]>p[j+1])
			{
				p[i]=p[j+1];
			}

		}

	}
}

void bsortlist(tpointer head)
{
	struct Node *i,*j;
	int temp;
	j=head;
	i->next=head->next;
	for(i=head;i!=NULL;i=head->next)
	{
		for(j=head;j!=NULL;j=j->next)
		{
			if(i->data > j->data)
				temp=i->data;
				i->data=j->data;
				j->data=temp;
		}
	}
}
void crearNodo(tpointer *head, int a)
{
	tpointer new; //Creamos un nuevo nodo
	new = malloc(sizeof(tnode)); //Utilizamos malloc para reservar memoria para ese nodo
	new->data = a; //Le asignamos el valor ingresado por pantalla a ese nodo
	new->next = *head; //Le asignamos al siguiente el valor de cabeza
	*head = new; //Cabeza pasa a ser el ultimo nodo agregado
}

void imprimirLista(tpointer head){
    while(head != NULL)				//Mientras cabeza no sea NULL
    {
        printf("%d",head->data);	//Imprimimos el valor del nodo
        head = head->next;
        if(head != NULL)
        	{
        	printf(" -> ");			//Pasamos al siguiente nodo
        	}
    }
    printf("\n");
}

void freemen(tpointer *head)//Funcion para liberar espacio de memoria
{
	tpointer current; //Puntero auxiliar para eliminar correctamente la lista

	    while(*head != NULL)
	    {
	        current = *head; //Actual toma el valor de cabeza
	        *head = (*head)->next; //Cabeza avanza 1 posicion en la lista
	        free(current); //Se libera la memoria de la posicion de Actual (el primer nodo), y cabeza queda apuntando al que ahora es el primero
	    }
}
int main(void)
{
	int valor=0;
	int *pvalor;
	int contador;
	pvalor=&valor;
	tpointer head;
	head=NULL;//el comienzo de la lista enlazada
	head = (struct Node*)malloc(sizeof(struct Node));
	printf("Ingrese un valor: ");
	scanf("%d",pvalor);
	head->data=*pvalor;
	printf("\nEl valor ingresado fue: %d, -1 para terminar.\n",head->data);
	while(1)
	{
		contador++;
		crearNodo(&head,*pvalor);
		printf("Ingrese un valor: ");
		scanf("%d",pvalor);
		if(*pvalor==-1)
			break;
		head->data=*pvalor;
		printf("\nEl valor ingresado fue: %d, -1 para terminar.\n",head->data);

	}
	//bsortlist(head);
	imprimirLista(head);
	freemen(&head);
	printf("Termino.");
	return 0;
}







